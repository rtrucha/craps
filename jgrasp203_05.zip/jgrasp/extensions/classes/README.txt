README - "system"

This file describes the contents of the system classes directory
as delivered with the jGRASP installation. When any of the provided 
compiler settings for Java are used, the java packages and/or class
files placed in this directory will be available to the compiler if 
files with the same names were not found in the local directory or 
earlier on the CLASSPATH.

Requests to have files included with the jGRASP distribution should 
be sent to the developers (jgrasp@auburn.edu).

Distribution:

cs1 (directory):
     contains files for the textbook "Java Software Solutions"
     by John Lewis and William Lofus, Addison Wesley, 2ed, 2001.
     (included at the request of the authors)

     Keyboard.class
     Keyboard.java
     KeyboardDesc.doc
     KeyboardDesc.pdf
