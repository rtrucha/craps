s
compiler environments
Microsoft Visual Studio (or Express)
 !D"  />  =H   ]
Sun cc - Solaris
  @V  +F  .N  !?
gcc - generic
  1V  ,]  /   !^
gcc - generic - Insight debugger
  _>  ,Z  1@  "P
gcc - MinGW - OpenGL32 with freeglut
 ":Z  -#  9H  #F
gcc - generic - OpenGL with GLUT
 "!J  -B  90  $8
cc (gcc) - Mac OS X
  OD  +   /Z  $]
DJGPP2
 !0^  +I  3$  %5
Borland BCC 5.5 - Windows
      ,#  1V  & 
