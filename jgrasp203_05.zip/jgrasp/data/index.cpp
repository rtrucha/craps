s
compiler environments
Microsoft Visual Studio (or Express)
 !E\  /O  6B   ]
c++ (g++) - Mac OS X
  O<  +4  0^  !C
g++ - generic
  0F  -.  /J  ""
DJGPP2
 !2X  +Z  3$  ":
Borland BCC 5.5 - Windows
      +X  0F  #%
Sun CC - Solaris
  @0  +S  /,  #G
g++ - MinGW - OpenGL32 with freeglut
 "6^  -8  :X  $=
g++ - generic - Insight debugger
 ! :  -+  2>  %/
g++ - generic - OpenGL with GLUT
 !\>  -W  :@  &!
